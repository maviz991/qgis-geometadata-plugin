Plugin Builder Results

Your plugin GeoMetadata was created in:
    C:\Users\mdaviz\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\GeoMetadata

What's Next:

  * Customize the pb_tool.cfg as required

  * Use pb_tool to compile and deploy your new plugin

  * Compile the resources file using pyrcc4

  * Test the plugin by enabling it in the QGIS plugin manager

  * Customize it by editing the implementation file: GeoMetadata.py

  * Create your own custom icon, replacing the default icon.png

  * Modify your user interface by opening GeoMetadata_dialog_base.ui in Qt Designer

For more information, see the PyQGIS Developer Cookbook at:
http://www.qgis.org/pyqgis-cookbook/index.html

(C) 2011-2019 GeoApt LLC - geoapt.com
